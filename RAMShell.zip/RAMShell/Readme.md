# Changelog
## Day 0  Dec 13
* 完成init,find,run_link函数
* 基本解决开发环境问题
### TODO
* ramfs.h的引用问题
* 检查find的实际可用性
